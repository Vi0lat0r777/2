<template>
  <div class="about">
    <h1>This web hosting HSMS connector for secs4net demo only.</h1>
    <h2>The functionality is the same with WinForm version</h2>
  </div>
</template>
