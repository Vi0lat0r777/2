﻿using System.Reflection;

using log4net.Config;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("EAP.Winform Host")]
[assembly : AssemblyDescription("EAP .NET Software Develop Kit")]
[assembly : AssemblyConfiguration("")]
[assembly : AssemblyCompany("DogMouse")]
[assembly: AssemblyProduct("EAP.Winform Host")]
[assembly: AssemblyCopyright("Copyright © DogMouse 2016")]
[assembly : AssemblyTrademark("DogMouse")]
[assembly : AssemblyCulture("")]

[assembly: AssemblyVersion("1.0.*")]

//
[assembly : AssemblyDelaySign(false)]
[assembly : AssemblyKeyFile("")]
[assembly : AssemblyKeyName("")]
[assembly: ComVisibleAttribute(false)]
[assembly: AssemblyFileVersionAttribute("1")]
